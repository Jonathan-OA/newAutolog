C:\Service\server.exe
C:\Service\src\server.jar
C:\Service\src\image.ico
1.8.0